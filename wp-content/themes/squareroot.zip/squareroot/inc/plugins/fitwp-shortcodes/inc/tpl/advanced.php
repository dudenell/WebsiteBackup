<label class="button fitsc-advanced">
	<?php _e( 'Advanced Settings', 'fitsc' ); ?>
	<input ng-model="advanced" type="checkbox" class="hidden">
</label>
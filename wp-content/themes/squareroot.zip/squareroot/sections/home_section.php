<div class="grid-container">
<div class="grid-inner">
<div class="overlay">
<?php
	the_content();
?>
</div>
</div>
</div>